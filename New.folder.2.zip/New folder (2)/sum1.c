#include<stdio.h>

void main()
{
    int n,sum;
    scanf("%d",&n);
    sum=(n*(n+1))/2;
    printf("%d",sum);
}
